#Instructions
  step 1: go to terminal--> new terminal--->command prompt
  step 2: type npm create vite@latest
  step 3: give appname,package name, selct react and cd foldername
  step 4: npm install
  step 5: npm run dev