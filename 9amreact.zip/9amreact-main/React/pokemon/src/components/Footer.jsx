import React from 'react'

function Footer() {
  return (
    <footer className=' bg-gray-400 text-white text-2xl text-center py-4'>
        This site belongs to PIKACHU copyrighted&copy; 2025.
    </footer>
  )
}

export default Footer
