import ClassComp from "./ClassComp"
function App ()
{
  return (
    <>
      <h1>Hello world</h1>
      <h2>Hello world</h2>
      <ClassComp />
    </>
  )
}
export default App