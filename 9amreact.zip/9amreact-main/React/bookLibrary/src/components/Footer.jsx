function Footer ()
{
    return (
        <footer>
            This site Belongs to Doremon &copy; 2024
        </footer>
    )
}
export default Footer