import React from 'react'

function Header() {
  return (
    <header>
         <h2>Book Library</h2>
    </header>
  )
}

export default Header
