import React from 'react'

function Footer() {
  return (
    <footer className=' bg-gray-400 text-white text-center text-2xl'>
      <h2>This site belongs to xyz&copy;2025</h2>
    </footer>
  )
}

export default Footer
