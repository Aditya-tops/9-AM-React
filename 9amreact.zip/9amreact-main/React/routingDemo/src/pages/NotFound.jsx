import React from 'react'

function NotFound() {
  return (
    <div>
      <h1>Not Found Page</h1>
    </div>
  )
}

export default NotFound
