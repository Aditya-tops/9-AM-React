import React from 'react'

function Child2() {
  return (
    <div>
      <h2>I'm child2</h2>
    </div>
  )
}

export default Child2
