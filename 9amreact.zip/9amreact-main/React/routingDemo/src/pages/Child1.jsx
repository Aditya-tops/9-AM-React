import React from 'react'

function Child1() {
  return (
    <div>
      <h1>I'm child1</h1>
    </div>
  )
}

export default Child1
