import React from 'react'

function Movie() {
  return (
    <div>
      
    </div>
  )
}

export default Movie
