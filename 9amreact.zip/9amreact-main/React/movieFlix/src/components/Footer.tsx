import React from 'react'

function Footer() {
    return <footer className=' bg-green-100 py-5 text-center text-2xl'>
      This site belongs to XYZ &copy; 2025
  </footer>
}

export default Footer
