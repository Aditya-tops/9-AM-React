import React from 'react'

function Header() {
  return <header className='bg-[#0d253f] text-white text-3xl text-center py-5'>MyMovies</header>
}

export default Header
