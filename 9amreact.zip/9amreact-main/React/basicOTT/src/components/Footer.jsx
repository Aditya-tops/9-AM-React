import React from 'react'

function Footer() {
  return <footer className=' bg-[#0d253f] text-2xl text-center text-white py-5'>This site belongs to xyz &copy; 2025</footer>
}

export default Footer
