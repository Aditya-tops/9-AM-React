import React from 'react'
import FormikForm from './components/FormikForm'
import './App.css'
function App() {
  return (
    <div>
      <FormikForm />
    </div>
  )
}

export default App
