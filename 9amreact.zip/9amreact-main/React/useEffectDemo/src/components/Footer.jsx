import React from 'react'

function Footer() {
  return (
    <div className=' bg-gray-600 text-2xl text-white text-center py-5'>
      This site belongs to &copy; 2025
    </div>
  )
}

export default Footer
