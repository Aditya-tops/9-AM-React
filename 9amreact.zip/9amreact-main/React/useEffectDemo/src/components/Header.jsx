import React from 'react'

function Header() {
  return (
    <header className=' bg-gray-700  text-2xl text-center text-white py-5'>
      Header
    </header>
  )
}

export default Header
