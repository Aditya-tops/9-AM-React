import React from 'react'

function projects() {
  return (
		<div className=' h-screen flex justify-center items-center'>
			<h1 className=' text-7xl'>Projects</h1>
		</div>
	)
}

export default projects
