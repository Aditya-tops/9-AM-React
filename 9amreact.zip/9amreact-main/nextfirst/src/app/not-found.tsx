import React from 'react'

function notFound() {
  return (
    <div>
      404 not found
    </div>
  )
}

export default notFound
