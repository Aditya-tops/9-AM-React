"use client"
import React from 'react'

function contact() {
  return (
		<div className=' h-screen flex justify-center items-center'>
			<h1 className=' text-7xl'>I'm contact page</h1>
		</div>
	)
}

export default contact
