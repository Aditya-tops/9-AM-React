import React from 'react'

function Home() {
  return (
    <div className=' h-screen flex justify-center items-center'>
      <h1 className=' text-7xl'>Hello world</h1>
    </div>
  )
}

export default Home
