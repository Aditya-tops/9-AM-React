"use client"
import React from 'react'

function page() {
  return (
		<div className=' h-screen flex justify-center items-center'>
			<h1 className=' text-7xl'>I'm about page</h1>
		</div>
	)
}

export default page
