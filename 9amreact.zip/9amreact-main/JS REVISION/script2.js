import { a } from './script.js'
import something from './script.js'
console.log(a)
something()